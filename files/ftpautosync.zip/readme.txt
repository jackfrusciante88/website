upload only new file and delete obsolete shit:
lftp -e "mirror -R -e -n /home/mattia/Projects/website /htdocs/files" -u epiz_24354905,Ahk1vMN8AMCJ ftpupload.net:21

download only  new files:
lftp -e "mirror -n /htdocs/files /home/mattia/Projects/website" -u epiz_24354905,Ahk1vMN8AMCJ ftpupload.net:21


download everything and delete what is not matching:
lftp -e "mirror -e /htdocs/files /home/mattia/Projects/website" -u epiz_24354905,Ahk1vMN8AMCJ ftpupload.net:21



execute lftp from script:
lftp -f /home/mattia/Projects/sync.x


lftp with grant access:
lftp epiz_24354905:Ahk1vMN8AMCJ@ftpupload.net:21/htdocs/files


upload command:
mirror -R -e -n /home/mattia/Projects/website /htdocs/files



incron instruction:
/home/mattia/Projects/website IN_CREATE,IN_DELETE,IN_MODIFY lftp -f /home/mattia/Projects/sync.x
